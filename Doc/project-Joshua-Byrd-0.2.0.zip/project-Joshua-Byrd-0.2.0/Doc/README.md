All documents should be stored in this folder. 
