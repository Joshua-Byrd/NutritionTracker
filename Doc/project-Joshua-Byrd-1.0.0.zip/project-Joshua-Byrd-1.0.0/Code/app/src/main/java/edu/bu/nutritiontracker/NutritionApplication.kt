package edu.bu.nutritiontracker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class NutritionApplication: Application() {

}