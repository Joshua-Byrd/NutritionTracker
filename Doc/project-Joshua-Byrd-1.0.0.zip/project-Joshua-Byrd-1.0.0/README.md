# METCS683Assignments
My name is Joshua Byrd and this repo stores the code for my term project in CS683.
